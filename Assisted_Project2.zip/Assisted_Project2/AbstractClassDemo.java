package Assisted_Project2;
abstract class mnc{
	mnc()
	{
		System.out.println("HI I am the MNC here............!!!!!1");
	}
	abstract void company1();
	abstract void company2();
	void EmployeeDetails()
	{
		System.out.println("Hi we are the previous employee of the mnc company");
	}
}
abstract class infosys extends mnc
{
	void company1()
	{
		System.out.println("Hi We are the company 1 employee its establized in 1989");
	}
	abstract void company2();
}
class child extends infosys
{
	void company2()
	{
		System.out.println("Hi we are the company 2 employees its establized in 1999");
	}
	void employeeBenifits()
	{
		System.out.println("Company provides cab facility,pf,night allowances");
	}
}
public class AbstractClassDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		mnc obj=new child();
		child c=new child();
		obj.company1();
		obj.company2();
		obj.EmployeeDetails();
		c.employeeBenifits();
	}

}
