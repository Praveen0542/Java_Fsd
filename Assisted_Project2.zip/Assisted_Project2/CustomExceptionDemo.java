package Assisted_Project2;
import java.util.Scanner;

public class CustomExceptionDemo {
	void checkSalary(int salary) throws salaryChecked{
		if(salary<2100)
		{
			throw new salaryChecked("you need to work hard");
		}
		else if(salary>2100 && salary<5000)
		{
			throw new salaryChecked("your salary is somehow good");
		}
		else if(salary>5100 && salary<9000)
		{
			throw new salaryChecked("salary is very good");
		}
		else{
			System.out.println("UnEmployeed");
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CustomExceptionDemo obj=new CustomExceptionDemo();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Salary of the Employee");
		int salary=sc.nextInt();
		try{
			obj.checkSalary(salary);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
			System.out.println("Catch block is executed");
			
		}finally{
			System.out.println("Finally block is executed");
		}
	}
	class salaryChecked extends Exception{
		salaryChecked(String s)
		{
			super(s);
		}
	}

}
