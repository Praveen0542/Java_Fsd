package Assisted_Project2;
class Shape
	{
		void Area(int l,int b)
		{
			System.out.println(l*b);
		}
	}
	class rectangle extends Shape
	{
		@Override  
		void Area(int l,int b)
		{
			System.out.println(l*b);
		}
	}
	class triangle extends Shape
	{
		@Override  
		void Area(int b,int h)
		{
			System.out.println(0.5*b*h);
		}	
	}
	class square extends Shape
	{
		@Override  
		void Area(int a,int a1)
		{
			System.out.println(a*a1);
		}
	}
	class rhombus extends Shape
	{
		@Override  
		void Area(int d1,int d2)
		{
			System.out.println(0.5*d1*d2);
		}
	}
	class DynamicPolymorphism{
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Shape s;
		s=new rectangle();
		s.Area(12, 3);
		s=new triangle();
		s.Area(23, 32);
		s=new square();
		s.Area(12,12);
		s=new rhombus();
		s.Area(34,4);
		
		
	}
}
