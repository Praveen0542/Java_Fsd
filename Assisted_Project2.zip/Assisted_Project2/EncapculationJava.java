package Assisted_Project2;

public class EncapculationJava {
	private int SecurityCode=1231;
	private String BranchName="Hdfc";
	private int BranchCode=1326;
	
	
	
	public int getSecurityCode() {
		return SecurityCode;
	}



	public void setSecurityCode(int securityCode) {
		this.SecurityCode = securityCode;
	}



	public String getBranchName() {
		return BranchName;
	}



	public void setBranchName(String branchName) {
		this.BranchName = branchName;
	}



	public int getBranchCode() {
		return BranchCode;
	}



	public void setBranchCode(int branchCode) {
		this.BranchCode = branchCode;
	}



	public static void main(String[] args) {
		EncapculationJava obj =new EncapculationJava();
		System.out.println("The Security Code is: "+obj.getSecurityCode());
		obj.setSecurityCode(13424);
		System.out.println("The Branch Name is: "+obj.getBranchName());
		obj.setBranchName("Axis");
		System.out.println("The Branchcode is: "+obj.getBranchCode());
		obj.setBranchCode(1345);

	}

}
