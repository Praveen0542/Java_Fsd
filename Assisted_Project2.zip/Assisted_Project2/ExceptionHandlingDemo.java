package Assisted_Project2;

public class ExceptionHandlingDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1,num2,num3;
		num1=21;
		num2=0;
		try
		{
			num3=num1/num2;
			System.out.println("I am was Stuck.....");
		}
		catch(ArithmeticException ae)
		{
			System.out.println("/ by zero Exception ");
			System.out.println(ae.getMessage());
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		finally{
			System.out.println("In the Finally Block i performed the Addition"+(num1+num2));
			num3=num1+num2;
			System.out.println("The value of the num3: "+num3);
		}
		System.out.println("I am the outside of the Try Block..........");
	}

}
