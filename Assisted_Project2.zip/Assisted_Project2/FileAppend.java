package Assisted_Project2;

import java.io.FileWriter;
import java.io.IOException;

public class FileAppend {

	public static void main(String[] args) {
		String data="\nThe new Text is appended to the following .txt folder";
		
		try {
			FileWriter output=new FileWriter("C:\\Eclipse Workspace\\praveen.txt",true);
			output.write(data);
			System.out.println("File is Appended Successfully.");
			output.close();
		} catch (IOException e) {
			System.out.println("File Append Failed");
		}

	}
}
