package Assisted_Project2;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class FileRead {

	public static void main(String[] args) throws IOException {
		 char[] data=new char[1000];
		 
		 try {
			FileReader input=new FileReader("C:\\Eclipse Workspace\\praveen.txt");
			input.read(data);
			System.out.println("Data is Read Successfully.");
			System.out.println(data);
		} catch (FileNotFoundException e) {
			
			System.out.println("Error in the Read File.");
		}

	}

}