package Assisted_Project2;
import java.io.FileWriter;
//import java.util.*;
public class FileWrite
{
	public static void main(String args[]) {
		String data= "Once upon a time a Tortoise and a Rabbit had an argument about who was faster.They decided to settle the argument with a race. They agreed on a route and started off the race. The rabbit shot ahead and ran briskly for some time. Then seeing that he was far ahead of the tortoise, he thought he'd sit under a tree for some time and relax before continuing the race. He sat under the tree and soon fell asleep. The tortoise plodding on overtook him and soon finished the race, emerging as the undisputed champ. The rabbit woke up and realized that he'd lost the race.";
	
	
	try {
	FileWriter output= new FileWriter("C:\\Eclipse Workspace\\praveen.txt");
	output.write(data);
	System.out.println("File Written Successfully");
	output.close();
	}
	catch(Exception e)
	{
		System.out.println("Error File: "+ e);
	}
}
}