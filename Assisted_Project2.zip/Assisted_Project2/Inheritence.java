package Assisted_Project2;

class product{
	int id=78;
	String name="Amul";
}
class A extends product{
	int count=50;
	String category="Butter";
	
}
class B extends product{
	int count=90;
	String category="milk";
	
}
class C extends product{
	int count=56;
	String category="Chooco";
	
}
class subclass_A extends  A
{
	int price=30;
	int total_price=price+count;
	
}
class Inheritence extends B
{
	int price =10;
	int total_price=price+count;
	

	public static void main(String[] args) {
		
		A obj1=new A();
		B obj2=new B();
		C obj3=new C();
		subclass_A obj4=new subclass_A();
		Inheritence obj5=new Inheritence();
		System.out.println("The product Id is: "+obj1.id);
		System.out.println("The product name is: "+ obj1.name);
		System.out.println("The Class A count is: "+ obj1.count);
		System.out.println("The Class A category is: "+ obj1.category);
		System.out.println();
		System.out.println("The product Id is: "+ obj2.id);
		System.out.println("The product name is: "+ obj2.name);
		System.out.println("The Class B count is: "+ obj2.count);
		System.out.println("The Class B category is: "+ obj2.category);
		System.out.println();
		System.out.println("The product Id is: "+ obj3.id);
		System.out.println("The product name is: "+ obj3.name);
		System.out.println("The Class C count is: "+ obj3.count);
		System.out.println("The Class C category is: "+ obj3.category);
		System.out.println();
		System.out.println("The Total price is: "+obj4.total_price);
		System.out.println("The product Id is: "+obj4.id);
		System.out.println("The product name is: "+ obj4.name);
		System.out.println("The Class A count is: "+ obj4.count);
		System.out.println("The Class A category is: "+ obj4.category);
		System.out.println();
		System.out.println("The Total price is: "+obj5.total_price);
		System.out.println("The product Id is: "+ obj5.id);
		System.out.println("The product name is: "+ obj5.name);
		System.out.println("The Class B count is: "+ obj5.count);
		System.out.println("The Class B category is: "+ obj5.category);
		System.out.println("!!!!!!!!!!!!!!!...............................!!!!!!!!!!!!!!");
	}

}
