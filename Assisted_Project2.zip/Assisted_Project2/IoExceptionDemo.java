package Assisted_Project2;
import java.io.IOException;
import java.util.Scanner;
public class IoExceptionDemo {
static int display(int l,int b) throws IOException
{
	if(l>b)
	{
		throw new IOException("IOException Occured");
	}else{
		System.out.println("Area of the Rectangle: "+l*b);
	}
	
	return l*b;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Length: ");
		int length=sc.nextInt();
		System.out.println("Enter the Breadth: ");
		int breadth=sc.nextInt();
		try{
		display(length,breadth);
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			System.out.println("The catch statement is Executed");
		}
		finally{
			System.out.println("The Finally statement is also Executed");
		}
	}

}
