package Assisted_Project2;
interface First 
{  
    default void show() 
    { 
        System.out.println("This is the interface first show method"); 
    } 
} 
interface Second 
{  
    default void show() 
    { 
        System.out.println("This is the Second Interface Show method"); 
    } 
}  

public class diamondProblem implements First,Second  {
	public void show() 
    {  
        First.super.show(); 
        Second.super.show(); 
    } 
    public static void main(String args[]) 
    { 
        diamondProblem ob = new diamondProblem(); 
        ob.show(); 
    } 
}
