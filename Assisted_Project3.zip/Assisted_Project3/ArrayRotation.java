package Assisted_Project3;
import java.util.Scanner;
public class ArrayRotation {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter a no of element in array");
	int n=sc.nextInt();
	int arr[]=new int[n];
	int last,j;
	System.out.println("Enter the array elements");
	for(int i=0;i<n;i++)
	{
		arr[i]=sc.nextInt();
	}
	System.out.println("How many right rotation");
	int m=sc.nextInt();
	for(int k=0;k<m;k++) {
		last=arr[n-1];
		for( j=n-1;j>0;j--) {
			arr[j]=arr[j-1];
			System.out.print(arr[j]+" ");
		}
		arr[0]=last;
	}
	System.out.println("After Right Rotation");
	for(int i=0;i<n;i++)
	{
		System.out.print(arr[i]+" ");
	}
	
}
}
