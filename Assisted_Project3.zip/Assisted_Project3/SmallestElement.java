package Assisted_Project3;

import java.util.Arrays;
import java.util.Scanner;

public class SmallestElement {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter a no of element in array");
	int n=sc.nextInt();
	int arr[]=new int[n];
	System.out.println("Enter the array elements");
	for(int i=0;i<n;i++)
	{
		arr[i]=sc.nextInt();
	}
	System.out.println("Enter the Kth of smallest number");
	int k=sc.nextInt();
	Arrays.sort(arr);
	System.out.println("The Kth smallest element is " + arr[k-1]);
}
}
