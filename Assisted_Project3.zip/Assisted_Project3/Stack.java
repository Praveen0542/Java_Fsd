package Assisted_Project3;

import java.util.Scanner;

public class Stack {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the size of stack :");
	int n=sc.nextInt();
	int top=-1;
	int stack[]=new int[n];
	System.out.println("Stack Operation");
	while(true) {
		System.out.println("Enter the choice 1.push 2.pop 3.display 4.exit ");
		int ch=sc.nextInt();
		switch(ch){
		//Overflow
		case 1: if(top==n-1) {
			System.out.println("stack is full no more insertion");
		}
		else {
			System.out.println("Enter the element to insert");
			int k=sc.nextInt();
			top++;
			stack[top]=k;
		}
		break;
		case 2:if(top==-1) {
			System.out.println("Stack is empty no del operation");
		}
		else {
			top=top-1;
		}break;
		case 3:if(top==-1) {
			System.out.println("stack is empty no display of element");
		}
		else {
			for(int i=top;i>=0;i--) {
				System.out.println(stack[i]);
			}
		}
		
		case 4:System.exit(0);
		break;
		default:System.out.println("check ur choice");
		break;
		}
	}
}
}
