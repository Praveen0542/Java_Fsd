package Assisted_Project3;

import java.util.Scanner;

public class SumofNNumber {
public static void main(String[] args) {
	int arr[]=new int[] {3,6,7,8,29,67};
	int sum=0;
	for(int i=0;i<arr.length;i++)
	{
		sum+=arr[i];
	}
	System.out.println("Sum of "+arr.length+" element is "+sum);
}
}
