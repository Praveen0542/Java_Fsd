package Assisted_project4;

public class BinarysearchDemo 
    {
    public static  void main(String[] args)
    {
        int[] arr = {3,6,9,12,15};
        int key = 12;
        int arrlength = arr.length;
        binarySearch(arr,0,key,arrlength);
    }

public static void binarySearch(int[] arr, int start, int key, int length)
{
        int centerValue = (start+length)/2;
        while(start<=length)
        {

            if(arr[centerValue]<key)
            {
                start = centerValue + 1;
            } 
            else if(arr[centerValue]==key)
            {
                System.out.println("Element is found at index :"+centerValue);
                break;
            }
            else 
            {
                length=centerValue-1;
            }
            centerValue = (start+length)/2;
        }
            if(start>length)
            {

                System.out.println("Element is not found");
            }
}
}
