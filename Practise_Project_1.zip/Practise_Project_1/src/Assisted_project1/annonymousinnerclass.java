package Assisted_project1;

abstract class Anonymousinnerclass {
	   public abstract void display();
	}

public class annonymousinnerclass {
	public static void main(String[] args) {
		Anonymousinnerclass obj = new Anonymousinnerclass() {

		         public void display() {
		            System.out.println("Anonymous Inner Class");
		         }
		      };
		      obj.display();
		   }


}
