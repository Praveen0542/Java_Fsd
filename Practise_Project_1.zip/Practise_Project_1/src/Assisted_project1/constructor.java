package Assisted_project1;

public class constructor
{
	int EmployeeId;
	 String EmployeeName;
	 String department;
	 float salary;
		
	 public constructor() {
	  EmployeeId=1;
	  EmployeeName="Praveen";
	  department=" IT profession ";
	  salary=25000;
	 }
		
	 public constructor(int EmployeeId,String EmployeeName,String department,float salary) 
	 {
	  this.EmployeeId=EmployeeId;
	  this.EmployeeName=EmployeeName;
	  this.department=department;
	  this.salary=salary;
	 }
		
	 public void display() 
	 {
	  System.out.println("Id of the Employee: "+EmployeeId);
	  System.out.println("Name of the Employee: "+EmployeeName);
	  System.out.println("Department : "+department);
	  System.out.println("Salary : "+salary);
	  System.out.println();
	  
	 }
		
	 public static void main(String[] args) 
	 {
	  
	  constructor e= new constructor();
	  constructor e1= new constructor( 24, "Prasanth", "Team Lead", 350000); 

	  e.display();
	  e1.display();
	  
	   
		
	 }

}
