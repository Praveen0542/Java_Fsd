package Assisted_project1;

//import innerClass.Inner;

public class innerClass {
	 private String msg="Welcome to the Trainig"; 
		 
		 class Inner{  
		  void hai(){System.out.println(msg+", Let us start Java-Fsd Inner Classes");}  
		 }  


		public static void main(String[] args) {

			innerClass obj=new innerClass();
			innerClass.Inner in=obj.new Inner();  
			in.hai();  
		}


	}
